geo.xml is OK ==> one data ceneter
chunkfiles is OK ==> 2000 file distributed on 20 host
bigfiles is OK ==>  files and we do not need them
DCRootLinks is OK ==> we do not use it at this example, only one Data cenetr
replicationtype is OK ==> we do not use it at this example
MapReduc 